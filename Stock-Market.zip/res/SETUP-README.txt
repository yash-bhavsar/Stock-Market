
To run the stock market simulator:

1. Use the jar files for Jfreechart, opencv and Apache Commons included in the /res folder in the zip.
2. 
3. Open IntelliJ, go to your project, go to project structure and add the jar files which have been unzipped.
3. Open command prompt.
4. Go to res folder using "cd Stock-Market/res/".
5. run jar file using "java -jar Stock-Market.jar -view type-of-view". (View can be GUI or console)

Libraries being used -
1. Opencv
2. JFreechart
3. Apache Commons
4. AlphaVantage API