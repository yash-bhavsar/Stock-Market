
To run the stock market simulator:

1. Open command prompt.
2. go to res folder using "cd Stock-Market/res/".
3. run jar file using "java -jar Stock-Market.jar".
